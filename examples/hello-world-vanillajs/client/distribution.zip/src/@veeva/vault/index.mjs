var e="1.0.2";var a=window;a.__vaultMeta.version=e;var{definePage:o,vaultApiClient:l}=a.__vaultModuleV5;export{o as definePage,l as vaultApiClient};
//# sourceMappingURL=index.mjs.map
